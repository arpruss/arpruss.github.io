uint8_t filterWord(char* s);
void getWord(uint16_t n, char* buffer);
void getSpecialWord(int16_t n, char* buffer);
#include "sizes.h"

