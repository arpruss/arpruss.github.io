# gb-fiver

FIVER is like Wordle, but for the Nintendo Game Boy!

